import React from 'react';

const NoMatch = () => {
    return <div>No Matching Route</div>;
};
export default NoMatch;
