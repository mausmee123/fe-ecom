import React from "react";

const AdminLayout = ({children}) => {
    return (
        <>
            {children}
        </>
    )
};

export default AdminLayout;