export const counter = (state) => state.auth.value;
export const isLoggedIn = (state) => state.auth.isLoggedIn;
